package com.softtek.java.academy.entities;

public enum ContactType {
	FAMILIAR, FRIEND, WORK, UNKNOWN
}